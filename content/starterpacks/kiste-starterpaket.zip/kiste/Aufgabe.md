Schreiben Sie ein Programm, in das der Benutzer die Höhe, Breite und Länge einer Kiste in dieser Reihenfolge eingeben kann. Danach sind die Höhe, Breite und Länge von Schachteln einzugeben. Berechnen Sie, wie viele Schachteln in die Kiste vollständig hineinpassen. Die Schachteln dürfen hierbei nicht gedreht werden, die Längsseite der Schachtel ist immer gemäß der Längsseite der Kiste ausgerichtet, usw.

Geben Sie das Ergebnis aus, andere Ausgaben soll Ihr Programm auch zur Unterstützung der Benutzerführung nicht machen.
