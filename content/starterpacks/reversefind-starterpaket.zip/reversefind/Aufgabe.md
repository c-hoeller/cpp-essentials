Entwickeln Sie eine Funktion reverseFind, die die Position des letzten Vorkommens einer gesuchten Zahl in einem Array mit Elementen vom Typ long bestimmt. Die Funktion erwartet als Argumente das Feld, dessen Länge und die gesuchte Zahl. Der Prototyp ist:

int reverseFind (long feld[], int len, long suchwert);

 Die erste Anweisung dieser Funktion muss

   printf("-%s-\n", __func__);

sein. Die Funktion liefert den Index des letzten Elements im Feld, das mit der gesuchten Zahl übereinstimmt, bzw. -1, falls die Zahl im Feld nicht vorkommt. Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
