Schreiben Sie eine Funktion mit dem Namen copyDistinct, der zwei Arrays mit Integerwerten sowie die Größe der beiden Arrays (Elementanzahl) übergeben wird. Der Prototyp ist

  int copyDistinct (int * source, int * dest, int anzahl)     oder wahlweise

  int copyDistinct (int source[], int dest[], int anzahl)

Die Funktion soll in dest beginnend ab Position 0 ohne Lücke alle Wert aus dem Array source eintragen, wobei jeder Wert nur einmal kopiert werden darf. Enthält source Werte doppelt, so sind diese im Ergebnis nur einmal aufzuführen.

Im Beispiel: Wenn source die Werte {3,6,7,7,2,1,3,3} enthält, dann soll danach dem Kopieren dest die Werte {3,6,7,2,1} enthalten.

Der Rückgabewert der Funktion ist dann die Anzahl der kopierten Werte, in diesem Fall 5.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
