# Duplikate aus Array entfernen

Du musst nur die Stelle mit `TODO` in `copydistinct.cpp` implementieren.
Alle Datenstrukturen, Ein-/Ausgabe und das Testgerüst sind bereits enthalten.

## Starten

Windows: `start.bat` doppelklicken.

macOS/Linux: In einem Terminal in diesem Ordner `bash start.sh` ausführen.

Beide Skripte benötigen einen C++-Compiler (`g++` bzw. `c++`).

## Testeingabe

Beim Start fordert das Programm eine Testeingabe an. Diese Eingabe funktioniert
direkt mit dem enthaltenen Testgerüst:

```text
15 20 21 22 23
```

Die vollständige Aufgabenbeschreibung steht in `Aufgabe.md`.
