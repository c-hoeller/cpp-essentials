Schreiben Sie eine Funktion zu einer der beiden folgenden Signaturen/Prototypen:
   int * vergroessern (int * arr, int laenge_arr);
   int * vergroessern (int arr[], int laenge_arr);
Der erste Befehl der Funktion soll folgender sein:
   printf("%s%d\n", __func__, arr[1]);
Die Funktion soll einen Vektor/Array mit der übergeben Länge vergrößert, indem innerhalb der Funktion ein neuer Vektor/Array angelegt wird, der zwei Einträge länger ist als die übergebene Länge des übergebenen Vektors/Arrays. Die Inhalte des übergebenen Vektors/Arrays sollen dabei alle in den neuen Vektor/Array kopiert werden. Neue Einträge sind mit -1 zu belegen. Der so neu aufgebaute Array ist als Ergebnis der Funktion zurückzugeben.
Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
