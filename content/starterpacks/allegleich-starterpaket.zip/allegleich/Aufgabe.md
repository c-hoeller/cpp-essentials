Schreiben Sie eine Funktion mit dem Namen allegleich, der ein Integerarray sowie die Anzahl der Elemente im Array übergeben werden soll, als Ergebnis soll die Funktion einen Wert vom Typ bool zurückgeben. Die erste Anweisung dieser Funktion muss

`printf("-%s-\n", __func__);`

sein. Prüfen Sie, ob in dem Array alle Werte identisch sind. Ist dies der Fall, so ist das Funktionsergebnis true, ansonsten false.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
