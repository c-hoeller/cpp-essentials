Schreiben Sie eine C-Funktion, der zwei Integer-Vektoren/Arrays mit ihrer Größe übergeben werden, und die einen Integer-Vektor/Array als Ergebnis zurückliefert. Die beiden Argumentarrays sind hierbei gleich groß, so dass nur eine Länge übergeben wird. Der Prototyp ist damit wahlweise

   int * mischen (int * arr1, int* arr2, int laenge_arr)    oder

   int * mischen (int arr1[], int arr2[], int laenge_arr)

Schreiben Sie eine Funktion, die dynamisch einen Integer-Array erzeugt, der die Inhalte beider Argumentarrays aufnehmen kann. In diesen Ergebnisarray sollen die Parameterarrays gemischt werden, indem die Werte abwechselnd beginnend mit arr1 eingetragen werden, damit erst das erste Element von arr1, dann das erste von arr2, dann das zweite von arr1, dann das zweite von arr2 usw. Das so erzeugte Array ist als Ergebnis zurückzuliefern.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
