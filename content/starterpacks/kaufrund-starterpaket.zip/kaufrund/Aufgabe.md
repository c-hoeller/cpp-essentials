Schreiben Sie eine C-Funktion kaufrund, die einen übergebenen double-Wert auf zwei Nachkommastellen kaufmännisch rundet (und damit bei der Grenze 5 aufrundet) und als Funktionswert zurückgibt.

Der erste Befehl der Funktion soll folgender sein:

`printf("-%s-\n", __func__);`

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.