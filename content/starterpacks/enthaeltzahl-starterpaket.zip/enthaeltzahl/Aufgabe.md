Schreiben Sie eine Funktion
   bool enthaelt_zahl (const char * str) oder wahlweise
   bool enthaelt_zahl (const char str[]).

Die erste Anweisung dieser Funktion muss
   printf("-%s-\n", __func__);
sein. Die Funktion soll prüfen, ob in der Zeichenkette eine Zahl enthalten ist. Es ist damit zu prüfen, ob innerhalb der Zeichenkette nur Ziffern und kein anderes Zeichen enthalten ist. Auch muss mindestens eine Ziffer vorhanden sein. Ist der Test erfolgreich, liefert die Funktion true, ansonsten false.
Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
