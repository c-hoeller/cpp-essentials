#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

compiler="${CXX:-c++}"
"$compiler" -std=c++20 -Wall -Wextra -Wpedantic "enthaeltzahl.cpp" -o "enthaeltzahl"
echo
"./enthaeltzahl"
