Schreiben Sie eine Funktion mit dem Namen qsumme, der ein Integerwert übergeben werden soll. Die erste Anweisung dieser Funktion muss
printf("%s\n", __func__);
sein. Ist der übergebene Integerwert kleiner als 0, so ist -1 als Funktionsergebnis zurückzugeben. Ansonsten ist die Quersumme der übergebenen Zahl zu ermitteln, also die Summe aller Ziffern, aus der die Zahl zusammengesetzt ist  (bei 125 also 1+2+5), und als Funktionswert zurückzugeben.
Hinweis: Mittels %10 bekommt man den Wert der letzten Stelle einer Integerzahl.
Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
