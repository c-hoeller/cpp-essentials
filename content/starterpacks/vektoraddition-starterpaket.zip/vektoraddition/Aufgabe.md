Definieren Sie eine Struktur mit dem Namen `vektor` und den drei Integerattributen `x`, `y` und `z`. Schreiben Sie eine Funktion zu folgendem Prototypen:

```
vektor addVektor (const vektor * a, const vektor * b)
```

, die einen neuen Vektor erzeugt, indem die beiden als Parameter übergebenen Vektoren addiert werden. Vektoren werden dabei addiert, indem diese komponentenweise addiert werden.

```
(a)   (d)   (a+d)
(b) + (e) = (b+e)
(c)   (f)   (c+f)
```

Der neu erzeugte Vektor ist als Funktionsergebnis zurückzugeben.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
