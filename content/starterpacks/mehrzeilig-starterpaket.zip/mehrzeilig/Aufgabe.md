Schreiben Sie eine Funktion zu folgendem Prototypen:
   void ausgabeMehrzeilig (const string & str);
Die Funktion soll die übergebene Zeichenkette ausgeben, wobei nach jedem Satzendepunkt ein Zeilenumbruch zu erzeugen ist. Durchlaufen Sie hierzu die Zeichenkette buchstabenweise, bei jedem Auftreten eines '.'-Zeichens ist nach der Ausgabe des '.'-Zeichens ein Zeilenumbruch zu erzeugen.
Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
