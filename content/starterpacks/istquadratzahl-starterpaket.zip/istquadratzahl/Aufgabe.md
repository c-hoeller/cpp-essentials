Schreiben Sie eine Funktion mit dem Namen istQuadratzahl, der ein Integer-Wert übergeben werden soll und die einen Wert vom Typ bool als Ergebnis hat. Die erste Anweisung dieser Funktion muss

   printf("%s\n", __func__);

sein. Die Funktion soll prüfen, ob das Argument eine Quadratzahl, also eine Zahl ist, die das Ergebnis der Multiplikation einer ganzen Zahl größer als 0 mit sich selbst ist. Beispiele von Quadratzahlen sind damit 1,4,9,16. Prüfen Sie dies, indem sie in einer Schleife aufsteigend mögliche Zahlen quadrieren und prüfen, ob dies mit dem Argument übereinstimmt. So ist dies zwar nicht performant, jedoch schnell umsetzbar.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
