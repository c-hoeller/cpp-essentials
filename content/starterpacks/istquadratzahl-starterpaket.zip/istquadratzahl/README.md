# Quadratzahl-Test per Schleife

Du musst nur die Stelle mit `TODO` in `istquadratzahl.cpp` implementieren.
Alle Datenstrukturen, Ein-/Ausgabe und das Testgerüst sind bereits enthalten.

## Starten

Windows: `start.bat` doppelklicken.

macOS/Linux: In einem Terminal in diesem Ordner `bash start.sh` ausführen.

Beide Skripte benötigen einen C++-Compiler (`g++` bzw. `c++`).

## Testeingabe

Beim Start fordert das Programm eine Testeingabe an. Diese Eingabe funktioniert
direkt mit dem enthaltenen Testgerüst:

```text
9
```

Die vollständige Aufgabenbeschreibung steht in `Aufgabe.md`.
