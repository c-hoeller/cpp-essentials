Schreiben Sie eine Funktion

   bool ist_palindron(const char * str) oder wahlweise

   bool ist_palindron (const char str[]).

Die erste Anweisung dieser Funktion muss

   printf("-%s-\n", __func__);

sein. Die Funktion soll prüfen, ob in der Zeichenkette ein Palindron gespeichert ist. Ist dies der Fall liefert die Funktion true, ansonsten false.

Ein Palindron liegt bei einer Zeichenkette vor, wenn diese vorwärts gelesen dasselbe Wort ergibt wie rückwärts gelesen. Ein Beispiel hierfür ist die Zeichenkette HANNAH. Sie dürfen davon ausgehen, dass in der Zeichenkette nur Groß- oder nur Kleinbuchstaben vorkommen.

Das Hauptprogramm main darf bei dieser Aufgabe im gekennzeichneten Bereich nicht verändert werden.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
