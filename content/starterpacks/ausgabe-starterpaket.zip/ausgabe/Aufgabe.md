Erzeugen Sie in einer main-Funktion einen Integer-Array der Länge 20.
Befüllen Sie diesen Array mit Benutzereingabe ab der Stelle 0, bis der Benutzer den Wert -1 eingibt. Der Wert -1 ist dabei auch in den Array  einzutragen. Ein Überprüfen der Arraygrenze von 20 ist nicht erforderlich, gehen Sie von weniger als 20 Eingaben aus. Rufen Sie mit dem Array die von Ihnen zu programmierende Funktion mit folgenderm Prototypen auf:
   void ausgabe (const int * p); 
   void ausgabe (const int p[]);
Der erste Befehl der Funktion soll folgender sein:
   printf("%s\n", __func__); 
Danach ist der Inhalt des Arrays auszugeben, bis die Position mit dem Wert -1 erreicht ist, die -1 soll hier nicht mit ausgegeben werden. Nach jeder Ausgabe ist ein Zeilenumbruch zu erzeugen. Ergänzende und erläuternde Ausgaben sind nicht gewünscht.
