Gegeben sei folgende Struktur:

    struct pers {
       string vname;
       string nname;
    };

Erzeugen Sie eine Variable von diesem Datentyp. Lassen Sie den Benutzer einen Vor- und einen Nachnamen eingeben (ohne erläuternde Ausgaben). Belegen Sie ihre Variable mit den Eingaben und rufen danach die gegebene Funktion eval mit einer Referenz auf Ihre Variable auf.

```cpp
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

void eval(pers * p)
{
   cout << __func__<< p->nname << p->vname;
}

int main()
{
   return 0;
}
```
