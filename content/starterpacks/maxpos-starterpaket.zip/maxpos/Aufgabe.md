Schreiben Sie eine Funktion mit dem Namen maxpos, der ein Integerarray sowie die Anzahl der Elemente im Array übergeben werden soll. Die erste Anweisung dieser Funktion muss

```
printf("%s\n", __func__);
```

sein. Ermitteln Sie innerhalb der Funktion die Position, an der in dem Array der größte Wert vorkommt. Geben Sie diese Position als Ergebnis zurück.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
