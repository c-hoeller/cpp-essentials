Schreiben Sie ein C++-Programm, in dem der Benutzer eine Zahl eingeben kann. Das Programm soll danach das Zeichen mit dem ASCII-Code der eingegebenen Zahl ausgeben.
