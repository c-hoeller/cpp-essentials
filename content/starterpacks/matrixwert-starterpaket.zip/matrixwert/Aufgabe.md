Initialisieren Sie einen zweidimensionalen Integer-Array mit den Werten und der Struktur der folgenden Tabelle:

```
2  5  7  9  2  4
1  7  3  7  9  2
3  6  8  2  5  8
```

Weiterhin soll der Benutzer eine Zeilennummer und eine Spaltennummer eingeben. Dabei beginnt die Nummerierung jeweils mit 0. Ausgegeben werden soll der Wert an der angegebenen Position bzw. -1, wenn die eingegebenen Werte nicht im Bereich der möglichen Positionen im Array liegen.
