#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

compiler="${CXX:-c++}"
"$compiler" -std=c++20 -Wall -Wextra -Wpedantic "uhrzeitminus.cpp" -o "uhrzeitminus"
echo
"./uhrzeitminus"
