Programmieren Sie eine Funktion zu folgendem Prototypen:
int get_value (const int * arr, int pos);
Die Funktion  soll den Wert des in arr übergebenen Intergerarrays an der Arrayposition pos zurückgeben.
Der erste Befehl der Funktion soll dabei folgender sein:
printf("%s\n", __func__);

Testen Sie Ihre Funktion mit der gegebenen main-Funktion.

```cpp
#include <stdio.h>
#include <iostream>
using namespace std;

int get_value (const int * arr, int pos){
  printf("%s\n", __func__);

  return arr[pos-1];
}

int main() 
{
   int pos;
   int a [] = {5,7,32,5,7,3,5,7};
   cin >> pos;
   cout << get_value (a,pos) << endl;
   return 0;
}
```
