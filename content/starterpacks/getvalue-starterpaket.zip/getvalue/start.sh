#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

compiler="${CXX:-c++}"
"$compiler" -std=c++20 -Wall -Wextra -Wpedantic "getvalue.cpp" -o "getvalue"
echo
"./getvalue"
