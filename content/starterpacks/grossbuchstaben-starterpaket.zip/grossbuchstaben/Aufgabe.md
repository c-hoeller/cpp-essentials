Schreiben Sie eine Funktion zu folgendem Prototypen:
   int anzahlGrossbuchstaben (const string & str);
Die Funktion soll ermitteln, wie viele Großbuchstaben (Buchstaben im Bereich ‚A‘ bis ‚Z‘) in der übergebenen Zeichenkette enthalten sind. Diese Anzahl ist als Funktionsergebnis zurückzugeben.
Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
