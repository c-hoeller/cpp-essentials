# Großbuchstaben in String zählen

Du musst nur die Stelle mit `TODO` in `grossbuchstaben.cpp` implementieren.
Alle Datenstrukturen, Ein-/Ausgabe und das Testgerüst sind bereits enthalten.

## Starten

Windows: `start.bat` doppelklicken.

macOS/Linux: In einem Terminal in diesem Ordner `bash start.sh` ausführen.

Beide Skripte benötigen einen C++-Compiler (`g++` bzw. `c++`).

## Testeingabe

Beim Start fordert das Programm eine Testeingabe an. Diese Eingabe funktioniert
direkt mit dem enthaltenen Testgerüst:

```text
Hildegunst Mythenmetz
```

Die vollständige Aufgabenbeschreibung steht in `Aufgabe.md`.
