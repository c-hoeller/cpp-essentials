Schreiben Sie ein C++-Programm, das einen Geldbetrag und danach einen Zinssatz (nicht als Prozentwert, also 0.1 statt 10 Prozent) jeweils in eine Gleitkommavariable einliest. Berechnen Sie den Wert des Geldbetrags, wenn dieser 10 Jahre zu dem eingegeben Zinssatz verzinst wird und geben diesen Wert aus. Verzichten Sie auf erläuternde Textausgaben.

Anmerkungen. Die Verzinsung für ein Jahr ergibt sich, wenn man den Betrag mit (1 + Zins) multipliziert. So ergibt sich der zu verzinsende Betrag für das nächste Jahr.
