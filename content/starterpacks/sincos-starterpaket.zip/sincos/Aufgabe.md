Schreiben Sie ein C++ Programm, das eine Gleitpunktzahl im Dialog einliest. Anschließend soll der Sinus und Cosinus dieser Zahl ausgegeben werden. Weitere Ausgaben sind nicht erforderlich!
Ihre Lösung darf den vorhandenen und entsprechend gekennzeichneten Code am Anfang und am Ende von main nicht verändern, ansonsten scheitert die Evaluation.
