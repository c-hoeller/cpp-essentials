# Zwei Variablen per Zeiger vertauschen

Du musst nur die Stelle mit `TODO` in `swap.cpp` implementieren.
Alle Datenstrukturen, Ein-/Ausgabe und das Testgerüst sind bereits enthalten.

## Starten

Windows: `start.bat` doppelklicken.

macOS/Linux: In einem Terminal in diesem Ordner `bash start.sh` ausführen.

Beide Skripte benötigen einen C++-Compiler (`g++` bzw. `c++`).

## Testeingabe

Beim Start fordert das Programm eine Testeingabe an. Diese Eingabe funktioniert
direkt mit dem enthaltenen Testgerüst:

```text
2 5
```

Die vollständige Aufgabenbeschreibung steht in `Aufgabe.md`.
