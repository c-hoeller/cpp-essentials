Man betrachte folgenden Programmausschnitt:

   int i;
   int j;
   …
   swap(&i,&j);

Schreiben Sie eine Funktion swap, die bei dem dargestellten Programmausschnitt den Inhalt der Variable i und j vertauscht, so dass nach dem Aufruf der Funktion in i der Wert von j steht und in j der Wert von i.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
