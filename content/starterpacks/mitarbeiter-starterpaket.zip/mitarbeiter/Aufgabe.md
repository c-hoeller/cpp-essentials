Man betrachte folgende Klassendefinition:


Mitarbeiter
-  int nummerManager
-  int pnr;
- string vorname;
- string nachname;
+ Mitarbeiter (vname : string, nname : string)
+ getPnr() : int



Setzen Sie die Klassendefinition vollständig um. Das statische Klassenelement nummerManager ist mit dem Wert 100 zu initialisieren. Im Konstruktor ist bei jedem neuen Mitarbeitenden zuerst der Wert des NummerManagers um eins zu erhöhen. Der sich so ergebende Wert soll dann als Personalnummer des im Konstruktor erzeugten Mitarbeiters verwendet werden. Alle anderen Attribute sind gemäß der Parameter zu initialisieren.

Im Hauptprogramm main muss für die Prüfung die Methode eval entkommentiert werden, eigener Testcode ist aus main zu entfernen.
