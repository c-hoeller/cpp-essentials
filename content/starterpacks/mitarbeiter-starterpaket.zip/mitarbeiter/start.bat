@echo off
setlocal
cd /d "%~dp0"

where g++ >nul 2>nul
if errorlevel 1 (
  echo Fehler: Kein g++-Compiler gefunden.
  echo Installiere z. B. MSYS2/MinGW-w64 oder starte die Vorlage in einer C++-IDE.
  pause
  exit /b 1
)

g++ -std=c++20 -Wall -Wextra -Wpedantic "mitarbeiter.cpp" -o "mitarbeiter.exe"
if errorlevel 1 (
  echo.
  echo Kompilierung fehlgeschlagen. Pruefe den TODO-Block in mitarbeiter.cpp.
  pause
  exit /b 1
)

echo.
"mitarbeiter.exe"
echo.
pause
