Im Basisprogramm sind eine Matrix a und ein Vektor b in Form von (zweidimensionalen) Arrays vorgegeben. Bei der Matrix gibt der erste Arrayindex die Zeile, der zweite die Spalte an. Addieren Sie die dritte Zeile (Index 2 ) der Matrix a mit der vierten Spalte (Index 3) der Matrix a komponentenweise (erster mit erstem Wert, zweiter mit zweitem, …) und tragen das jeweilige Ergebnis an die gleiche Position in b ein.

Ihre Lösung darf den vorhandenen und entsprechend gekennzeichneten Code am Anfang und am Ende von main nicht verändern, ansonsten scheitert die Evaluation.
